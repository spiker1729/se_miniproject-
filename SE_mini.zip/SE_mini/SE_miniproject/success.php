<?php
    session_start();

    include("connection.php");
    
    $_SESSION['username_mgs'] = "Your Username is ";
    $_SESSION['pass_pass'] = "Now your Current password is ";
?>

<!DOCTYPE html>
<html>
<head>
<title>login-form</title>
<link rel="stylesheet" href="Design.css">

</head>
<body>
<?php
    include('header.php');
?>
    <div class="container">
        <div class="form">
            <h1>Password updated successfully</h1>
            <form action="" method="post">
                                    
                    <label><b>User Name</b></label>
                    <?php echo $_SESSION['username_mgs']; ?>
                    <?php echo $_SESSION['username']; ?>
            
                    
                    <div class="clearfix">
                        <button type="submit" class="btn"><a href="login1.php">Log In</a></button>
                        
                    </div>
            </form>
        </div>
    </div>

</body>

</html>
