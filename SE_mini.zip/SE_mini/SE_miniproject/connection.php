<?php
  $servername = "localhost";
  $username = "root";
  $userpassword = "password";
  $dbname = "itlab";

  $conn = mysqli_connect($servername, $username, $userpassword, $dbname);

  if($conn){
    /*echo "<script>alert('Connection Successfull')</script>";
    if(!isset($_SESSION)){
      session_start();
      }*/
  }
  else{
    die("Connection failed because".mysqli_connect_error());
    echo "<script>alert('Does not Connect to data base')</script>";
  }

?>
