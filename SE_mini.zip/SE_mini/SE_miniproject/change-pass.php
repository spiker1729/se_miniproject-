<?php
  session_start();

  if(!$_SESSION['username']){
    header('location:reset-pass.php');
  }

  include("connection.php");

if(isset($_POST['update'])){
  $username = $_POST['username'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];

  $new_pass_hash = password_hash($new_password, PASSWORD_DEFAULT);

  $user_search = " SELECT * FROM itlabexerciseusers WHERE username = '$username' ";
  $query = mysqli_query($conn, $user_search);

  $user_count = mysqli_num_rows($query);
  if($user_count){
    $user_pass = mysqli_fetch_assoc($query);

    $db_pass = $user_pass['password'];
    //echo "$db_pass";
    $_SESSION['username'] = $user_pass['username'];

    $pass_decode = password_verify($current_password, $db_pass);
    //echo "$user_search";

    if($pass_decode){

            $sql = "UPDATE itlabexerciseusers SET password ='$new_pass_hash' WHERE username = '$username' ";

      if (mysqli_query($conn, $sql)) {
        //echo "Password Change successfully";
          //header('location:change-pas.php');
          echo "<script>alert('Password Change successfully Go to login')</script>";
        header("location:success.php");
      } else {
        echo "Error updating record: " . mysqli_error($conn);
      }
    }
    else{
      echo "<script>alert('Incorrect Password')</script>";
    }
  }
  else{
    echo "<script>alert('Invalid User Name Please check')</script>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>change-password</title>
<link rel="stylesheet" href="Design.css">
<style>
     body{

background-image: url("https://images.pexels.com/photos/1242348/pexels-photo-1242348.jpeg?auto=compress&cs=tinysrgb&w=600");           background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;


        }
form {
  width: 80%;
  margin: 0 auto;
}






  </style>
</head>
<body>
<?php
    include('header.php');
?>
  <div class="container">
        <div class="form">
          <h2 style="background-color:#FFF; text-align:center"><b style="color:#F00;"><?php echo $_SESSION['reset_mgs']?></b></h2>
                <div class="clearfix">
                    <label style="background-color:#FFF;color:black">
                      <span>
                          <?php echo $_SESSION['pass_mgs']?>
                            <b style=" background:#FF0;color:#000000; font-size:24px;">
              <?php echo $_SESSION['gen_pass']?>
                        </b>
                        </span>

                    </label>
                </div>
            <br>
            <h2>Change Password</h2>
            <form action="" method="post">

                    <label><b>User Name</b></label>
          <input type="text" placeholder="Enter User Name" name="username" required>

                    <label><b>Current Password</b></label>
                    <input type="password" placeholder="Enter Current Password" name="current_password" required>

                    <label><b>New Password</b></label>
                    <input type="password" placeholder="Enter New Password" name="new_password" required>

                    <div class="clearfix">

            <a href="reset-pass.php"><button type="submit" name="update" class="btn">Change Password</button></a>
            <a href="login1.php"><button type="button" class="btn">Log In</button></a>
                    </div>
      </form>
      </div>
    </div>

</body>

</html>
