<?php
    session_start();
    session_destroy();
    setcookie('user_cookie', '', time()-86400);
    setcookie('pass_cookie', '', time()-86400);
    header('location:login1.php');
?>
