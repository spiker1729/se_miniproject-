<?php
  session_start();
  include("connection.php");

if(isset($_POST['login']))
{
  $username = $_POST['username'];
  $password = $_POST['password'];
  $user_type = $_POST['user_type'];


  $user_search = " SELECT * FROM itlabexerciseusers WHERE username = '$username' and user_type = '$user_type' ";
  $query = mysqli_query($conn, $user_search);

  $user_count = mysqli_num_rows($query);
  if($user_count)
  {
    $user_pass = mysqli_fetch_assoc($query);
    $db_pass = $user_pass['password'];
    $_SESSION['username'] = $user_pass['username'];
    $pass_decode = password_verify($password, $db_pass);
    echo $pass_decode;
    if($pass_decode)
    {
        if(isset($_POST['remember_me']))
        {
          setcookie('usernamecookie',$username,time()+86400);
          setcookie('passwordcookie',$password,time()+86400);
          echo "Login Successful";
          if($user_type == 'admin')
          {
            header('location:admin.php');
          }
          else
          {
            header('location:user.php');
          }
      //    header("location:welcome.php");

        }
        else
        {
          if($user_type == 'admin')
          {
            header('location:admin.php');
          }
          else
          {
            header('location:user.php');
          }
        //  header("location:welcome.php");
        }
    }
    else
    {
      echo "<script>alert('Incorrect Password')</script>";
    }
  }
  else
  {
    echo "<script>alert('Invalid User Name Please check')</script>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>login-form</title>
  <link rel="stylesheet" href="Design.css">
</head>

<body style="">
<?php
    include('header.php');
?>
  <div class="container">
        <div class="form" style="">
            <h1>Login TO the inventory management system</h1>
            <form action="" method="post">

                    <label><b>User Name</b></label>
                    <input type="text" placeholder="Enter Username" name="username" value="<?php if(isset($_COOKIE['usernamecookie'])){ echo $_COOKIE['usernamecookie'];} ?>">

                    <label><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="password" value="<?php if(isset($_COOKIE['passwordcookie'])){ echo $_COOKIE['passwordcookie'];}?>">

                    <label><b>User type</b></label>
                    <input type="text" placeholder="Enter admin/user" name="user_type" value="">


                    <input type="checkbox" name="remember_me"> Remember me
                    <p>Forgot Password <a href="reset-pass.php">Click here</a>.</p>

                    <div class="clearfix">
                        <button type="submit" name="login" class="btn">Log In</button>
                        <button type="submit" class="btn"><a href="signup.php">Create New</a></button>
                    </div>
      </form>
      </div>
    </div
</body>
