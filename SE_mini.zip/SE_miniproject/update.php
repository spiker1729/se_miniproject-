
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

session_start();

echo " <b>hello ".$_SESSION['user_type'] ;

echo"hello ".$_SESSION['username']; 

?>

    
    <?php
  
    
    if(isset($_GET["time"]) )
    {
        $data = $_GET["time"];
        $count=$_GET["count"];
      
     
    }
    
    
  
    include "connection.php";
    $sql = " update item_details set quantity_available = quantity_available-'$count' where item_id='$data'";
    
    $result = $conn->query($sql);

    $sql1 = " select * from item_details where item_id='$data'";

  
    $result1 = $conn->query($sql1);
      while($row = $result1->fetch_assoc())
        {
            $item_id= $row["item_id"];
            $item_name = $row["item_name"];
          
            $quantity_available = $row["quantity_available"];
           
          

            
            $sql2 = "INSERT INTO item_booked VALUES('{$_SESSION['user_name']}',$item_id,'$item_name',$data,$quantity_available,NOW())";
             $result3 = $conn->query($sql2);
            if ($result3 == TRUE) {
                echo "<script>
alert('ITEMS stock updated successfully');
window.location.href='http://localhost/SE_miniproject/user_event.php';
</script>";
            }
            
            else{echo "Error:". $sql . "<br>". $conn->error;
            }

        }
    
   
    $conn->close();
    

?>
</body>
</html>