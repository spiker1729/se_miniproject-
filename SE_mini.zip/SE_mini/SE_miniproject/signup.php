<?php
    session_start();
    include("connection.php");
    
if(isset($_POST['signup']))
{
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);
    $mobile_no = mysqli_real_escape_string($conn, $_POST['mobile_no']);  
    $user_type= mysqli_real_escape_string($conn, $_POST['user_type']);
    $pass = password_hash($password, PASSWORD_DEFAULT);
    $userquery = "SELECT * FROM itlabexerciseusers WHERE username = '$username' ";
    $query = mysqli_query($conn, $userquery);
    $usercount = mysqli_num_rows($query);
 //  echo $pass;
  //check length of mobile number is 10 or not and land on filled form

  
    if($usercount>0)
    {
        ?>
        <script>
             alert("User Name already exists");
        </script>
     <?php              
    }
    else{


        if(strlen($mobile_no) != 10){
            ?>
            <script>
                 alert("mobile number must be 10 digit");
                 
            </script>
         <?php  
        }
    
    else
    {
        if($password === $confirm_password){
           
            $insertquery = "INSERT INTO itlabexerciseusers (username,password,phone,user_type) VALUES ('$username','$pass','$mobile_no','$user_type')";

            $iquery = mysqli_query($conn, $insertquery);

            if($iquery)
            {
                
        
                ?>
                    <script>
                        alert("Registration Successfully...Please Login.");
                        window.location.href = "login1.php";
                    </script>
                <?php
                
               
            }
            else
            {
                ?>
                <script>
                    alert("Data Not Inserted");
                </script>
            <?php
            }
        }
        else
        {
            ?>
            
                <script>
                    alert("Passwords does not matched");
                </script>
            <?php
           /* header("location:login1.php");*/
        }

    }
}
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registation-form</title>
    <link rel="stylesheet" href="Design.css">
</head>

<body>
    <div class="header">
    </div>
    <div class="container">
        <div class="form">
            <h1>Registration Form</h1>
            <form action="" method="post">
                
                    <label><b>User Name</b></label>
                    <input type="text" placeholder="Enter Username" name="username" required>
        
                    <label><b>Password</b></label>
                    <input type="password" placeholder="Enter Password" name="password" required>
        
                    <label><b>Confirm Password</b></label>
                    <input type="password" placeholder="Confirm Password" name="confirm_password" required>
                    
                    <label><b>Mobile Number</b></label>
                    <input type="text" placeholder="Enter Mobile Number" name="mobile_no"   required >
                    
                    <label><b>User Type</b></label>
                    <input type="text" placeholder="Enter admin/user" name="user_type"   required >




                    <p>Forgot Password <a href="reset-pass.php">Click here</a>.</p>
        
                    <div class="clearfix">
                        
                        <button type="submit" name="signup" class="btn">Register</button>
                        <a href="login1.php"><button type="button" class="btn">Log In</button></a>
                    </div>
            </form>
        </div>
    </div>
</body>
</html>
