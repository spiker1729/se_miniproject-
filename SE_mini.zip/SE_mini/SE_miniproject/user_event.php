
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <?php
session_start();
//echo " <b>hello ".$_SESSION['user_type'] ;
echo "<center>";
echo "<hr>";
echo"<div style='font-size:1.25em;font-color:#0e3c68'>HELLO : </b>".$_SESSION['username']; 

echo "</center>";
echo "<hr>";

$name=$_SESSION['username'];
?>
	<?php
if(isset($_POST['logoutButtonName'])) {
  session_destroy();

  header('location:login1.php');
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <script type="text/javascript" src="jquery.js"></script>
<script type="text/javascript" src="modify_records.js"></script>
    <title>dummy</title>

    <?php

$conn =mysqli_connect("localhost","root","password","itlab") or die("connection failed");

$sql ="select item_name from item_details";

$query =mysqli_query($conn,$sql) or die("query failed");


?>
  <style>
     body{

background-image: url("https://images.pexels.com/photos/1242348/pexels-photo-1242348.jpeg?auto=compress&cs=tinysrgb&w=600");           background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;


        }
form {
  width: 80%;
  margin: 0 auto;
}






  </style>
</head>
<body>
<form action="" method="post">

<br>
<button type="submit" name="logoutButtonName" class="btn btn-primary" style="right">Logout</button>
</from>
    <center>
    <fieldset>
<legend>UPDATE ITEM'S STOCK INVENTORY:</legend >
<form style="padding:50px" action="" method="post">
    <center>
    <label >Select  city:</label>
    <select id="city" name ="city">
  <option value="0">choose item name</option>
    <?php while ($row = mysqli_fetch_assoc($query)) : ?>
                            <option value="<?php echo $row['item_name']; ?>"> <?php echo $row['item_name']; ?> </option>
                        <?php endwhile; ?>
</select>
<br><br>
<label for="" hidden></label>


    <select id="category" name="category" hidden>
        <option value="" ></option>
    </select>
    <button type="submit" name="submit" class="button">SEARCH</button>

    </center>

    
<table class="table">
        <thead>
            <tr>
                <th>item id</th>
                <th>item name</th>
                <th>total_quantity</th>
                <th>quantity_available</th>
				<th>date</th>
				<th>ACTION</th>
            
                
            </tr>
        </thead>

        <tbody>
            <?php   
            if(isset($_POST['submit'])){
                $selected_val = $_POST['city'];  // Storing Selected Value In Variable
               
                 // Storing Selected Value In Variable
                
            
            $severname="localhost";
            $username="root";
            $password="password";
            $database="itlab";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }

            $sql="select * from item_details where item_name='$selected_val'  and  quantity_available>0";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
            
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
            <td>". $row["item_id"]."</td>
            <td>". $row["item_name"]."</td>
            <td>". $row["total_quantity"]."</td>
            <td>". $row["quantity_available"]."</td>
			<td>". $row["item_purchased_date"]."</td>
         
            
            <td><a href='noof.php?time=".$row['item_id']."'>UPDATE</a></td>
            </tr>";
            }

        }
            ?>
        </tbody>
    </table>
        
    </fieldset>
</form> 
<br><hr><br>

<form action="" method="post">
<center>

<p> AVAILABLE STOCK OF ITEMS</p>


</center>
   
<table class="table">
        <thead>
            <tr>
            <th>item id</th>
                <th>item name</th>
                <th>total_quantity</th>
                <th>quantity_available</th>
				<th>date</th>
            </tr>
        </thead>

        <tbody>
            <?php   
            if(isset($_POST['submit'])){
                $selected_val = $_POST['category']; 
                $selected_val1 = $_POST['city'];
                 // Storing Selected Value In Variable
                
            
            $severname="localhost";
            $username="root";
            $password="password";
            $database="itlab";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }
        
            
           
            $sql="select * from item_details;";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
                <td>". $row["item_id"]."</td>
                <td>". $row["item_name"]."</td>
                <td>". $row["total_quantity"]."</td>
                <td>". $row["quantity_available"]."</td>
                <td>". $row["item_purchased_date"]."</td>
            </tr>";
            }

        }
            ?>
        </tbody>
    </table>

</form>


<script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>

<script type="text/javascript">
        $('#city').on('change', function(result) {
        var value = this.value;
     //console.log(value);
        $.ajax({
            url: 'dummy2.php',
            type: "POST",
            data: {
               value: value
            },
            success: function(result) {
                $('#category').html(result);
                 console.log(result);
            }
        })
    });


</script>

</body>
</html>