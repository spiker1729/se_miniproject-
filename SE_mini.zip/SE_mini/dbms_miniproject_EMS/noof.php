<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    

</head>
<body>
<center>
    <form action=""  method="posT">
    <input type="number" name="count" >
 
    <input type="submit" name="submit" value="ENTER"  >
    
</form>
    <?php
   $data=0;
    $coun=0;
   
    if(isset($_GET["time"]) )
    {
        $data= $_GET["time"];
    }
if(isset($_POST['count']))
{
    $GLOBALS['coun'] = $_POST['count'];
}

echo $coun;
echo" <a href='update.php?time=".$data."&count=".$coun."' >Book</a>";

include "configdb.php";
$sql = " select available_seats from event_details where event_time='$data'";
$result = $conn->query($sql);
while($row = $result->fetch_assoc())
{
    $available_seats = $row["available_seats"];
    echo "<br> $available_seats  seats are ";
   // echo $coun;
    if($available_seats>=$coun)
    {
        echo "available";
    }
    else
    {
        echo "<script>
        alert('seats not aviailable try again   ');
        window.location.href='';
        </script>";
    }
}

?>
</center>







</body>
</html>