<?php
session_start();



include "connection.php";
if (isset($_POST['submit'])) {

$item_id = $_POST['item_id'];
$item_name= $_POST['item_name'];
$total_quantity = $_POST['total_quantity'];
$quantity_available= $_POST['quantity_available'];
$date = $_POST['date'];


$sql = "INSERT INTO item_details (item_id,item_name,total_quantity,quantity_available, item_purchased_date)
VALUES($item_id,'$item_name',$total_quantity,$quantity_available,'$date')";

$result = $conn->query($sql);
if ($result == TRUE) {

// diplay alert message when data inserted successfully and redirect to login.php page after 5 seconds.
echo "<script>alert('New item added successfully')</script>";
echo "<script>window.open('admin.php','_self')</script>";

}else{echo "Error:". $sql . "<br>". $conn->error;
}

$conn->close();
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add_event</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>
<body>
<form action="" name="add_item" method="POST"  class="form-row">
 <div class="h-100 d-flex align-items-center justify-content-center">  
<fieldset>
<legend>Add-item </legend>
 	ITEM id:<br>
<input type="text" name="item_id" required>
<br>
event type:<br>
    <select name="item_name" id="">
    <option hidden > SELECT item</option>
    <option > GHOBHI</option>
    <option> DHANIYA </option>
    <option >BEET ROOT </option>
    <option > GROUND NUT</option>
    <option >  SUGAR </option>
    <option>  SALT   </option>
    <option > ONION </option>
    <option >  GARLIC   </option>
    <option > GINGER</option>
    <option > GREEN PEAS</option>

        </select>
        <br>
<br>


TOTAL quantity:<br>
<input type="number" name="total_quantity" required>
<br>
QUANTITY available<br>
<input type="number" name="quantity_available" required>
<br>

PURCHASE date:<br>
<input type="date" name="date" required>

<br>
<input type="submit" name="submit" value="submit" >
</fieldset>
</div>
</form>
</body>
</html>