<?php
  session_start();
  
  include("connection.php");
  $_SESSION['reset_mgs'] = "Reset your Password";
  $_SESSION['pass_mgs'] = "Now your Current password is";
  
//Random Password Generated
function password_generate($chars) 
{
  $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  return substr(str_shuffle($data), 0, $chars);
}
  
if(isset($_POST['reset'])){
  $username = $_POST['username'];
  $mobile_no = $_POST['mobile_no']; 
  
  //echo "$mobile_no";
   
  $user_search = " SELECT * FROM itlabexerciseusers WHERE username = '$username' ";
  $query = mysqli_query($conn, $user_search);
  
  $user_count = mysqli_num_rows($query);
  if($user_count){
    $user_pass = mysqli_fetch_assoc($query);
    $_SESSION['username'] = $username;
    
    $db_mob = $user_pass['phone'];
    
    if($mobile_no === $db_mob){
            $gen_pass = password_generate(8);
      //echo "You Successfully reset your password. Your new password is:  ";
      echo $gen_pass;
      $_SESSION['gen_pass'] = $gen_pass;

      $hash_pass = password_hash($gen_pass, PASSWORD_DEFAULT);
            
      $sql = "UPDATE itlabexerciseusers SET password ='$hash_pass' WHERE username = '$username' ";

      if(mysqli_query($conn, $sql)) 
      {
        ?>
        <script>alert('Password Reset Successfully')</script>
                <?php 
          header("location:change-pass.php");
      } 
      else 
      {
        echo "Error updating record: " . mysqli_error($conn);
      }

    }
    else
    {
      echo "<script>alert('Invalid Mobile Number')</script>";
    }
  }
  else
  {
    echo "<script>alert('Invalid UserName')</script>";
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>reset-password</title>
  <link rel="stylesheet" href="Design.css">
  <style>
     body{

background-image: url("https://images.pexels.com/photos/1242348/pexels-photo-1242348.jpeg?auto=compress&cs=tinysrgb&w=600");           background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;


        }
form {
  width: 80%;
  margin: 0 auto;
}






  </style>

</head>
<body>
<?php
    include('header.php');
?>
  <div class="container">
        <div class="form">
            <h2>Reset Password</h2>
            <form action="" method="post">
                
                    <label><b>User Name</b></label>
                    <input type="text" placeholder="Enter Username" name="username">
        
                    <label><b>Mobile Number</b></label>
                    <input type="text" placeholder="Enter Mobile Number" name="mobile_no">

          <!--<div class="clearfix">
            <label><b>
              <?php //echo $_SESSION['gen_pass']?>
            </b></label>
          </div> -->
          <!--<?php 
            //if($_SESSION['gen_pass']){
              ?>
                            <span>Create a New Password:   <a href="change-pass.php">Click here</a>.</span>
                            <?php
            //}
            //else{
              ?>
              <span>&nbsp;</span>
                            <?php
            //}
          ?>-->
          
                    
                    <!--<input type="checkbox" checked="checked"> Remember me -->
                    
        
                    <div class="clearfix">
                        
            <a href=""><button type="submit" name="reset" class="btn">Reset</button></a>
                    </div>
      </form>
      </div>
    </div>

</body>

</html>
