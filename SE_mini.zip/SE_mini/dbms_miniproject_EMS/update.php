
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php

session_start();

echo " <b>hello ".$_SESSION['user_type'] ;

echo"hello ".$_SESSION['user_name']; 

?>

    
    <?php
  
    
    if(isset($_GET["time"]) )
    {
        $data = $_GET["time"];
        $count=$_GET["count"];
      
     
    }
    
    
  
    include "configdb.php";
    $sql = " update event_details set available_seats=available_seats-'$count' where event_time='$data'";
    $result = $conn->query($sql);
    $sql1 = " select * from event_details where event_time='$data'";

  
    $result1 = $conn->query($sql1);
      while($row = $result1->fetch_assoc())
        {
            $city = $row["city_name"];
            $category = $row["event_category"];
            $date = $row["event_date"];
            $time = $row["event_time"];
            $total_seats = $row["total_seats"];
            $available_seats = $row["available_seats"];
            $ticket_price = $row["ticket_price"];


            
            $sql2 = "INSERT INTO ticket_booked VALUES('{$_SESSION['user_name']}',$available_seats+251,'$city','$category','$date','$time','booked',$count)";
             $result3 = $conn->query($sql2);
            if ($result3 == TRUE) {
                echo "<script>
alert('TICKET BOOKED successfully');
window.location.href='http://localhost/dbms_miniproject_EMS/user_event.php';
</script>";
            
            }
            
            else{echo "Error:". $sql . "<br>". $conn->error;
            }

        }
    
   
    $conn->close();
    

?>
</body>
</html>