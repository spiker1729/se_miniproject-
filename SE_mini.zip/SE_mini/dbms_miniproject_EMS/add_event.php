<?php
session_start();



include "configdb.php";
if (isset($_POST['submit'])) {

$password = $_POST['city_name'];
$name= $_POST['event_category'];
$age = $_POST['date'];
$address= $_POST['time'];
$aadhar_no = $_POST['total_seats'];
$phone_no= $_POST['available_seats'];
$user_type= $_POST['ticket_price'];

$sql = "INSERT INTO event_details (city_name,event_category,event_date,event_time,total_seats,available_seats,ticket_price)
VALUES('$password','$name','$age','$address',$aadhar_no,$phone_no,$user_type)";

$result = $conn->query($sql);
if ($result == TRUE) {
    echo '<script>alert("Event added successfully")</script>';
    
  
//echo "New record created successfully.";
}else{echo "Error:". $sql . "<br>". $conn->error;
}
header("Location: http://localhost/dbms_miniproject_EMS/admin__event.php");
$conn->close();
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>add_event</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

</head>
<body>







<form action="" name="add_event" method="POST"  class="form-row">
 <div class="h-100 d-flex align-items-center justify-content-center">  
<fieldset>
<legend>Add event </legend>
 	city name:<br>
<input type="text" name="city_name" required>
<br>
event type:<br>
    <select name="event_category" id="">
    <option hidden > SELECT EVENT</option>
    <option > Comedy</option>
    <option> Birthday </option>
    <option > Motivational talks </option>
    <option > festival celebration</option>
    <option >  Exhibition</option>
    <option>  Blood Donation Camp  </option>
    <option > Birthday </option>
    <option >  Anniversary   </option>
    <option > Farewell party </option>
    <option > Bhagwat katha </option>

        </select>
        <br>
date:<br>
<input type="date" name="date" required>
<br>
time:<br>
<input type="time" name="time" required>
<br>

total seats:<br>
<input type="text" name="total_seats" required>
<br>
seats available<br>
<input type="text" name="available_seats" required>
<br>
ticket price:<br>
<input type="text" name="ticket_price" required>
<br>
<br>
<input type="submit" name="submit" value="submit" >
</fieldset>
</div>
</form>
</body>
</html>