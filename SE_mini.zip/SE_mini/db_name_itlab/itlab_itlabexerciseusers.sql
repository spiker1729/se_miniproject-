-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: itlab
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `itlabexerciseusers`
--

DROP TABLE IF EXISTS `itlabexerciseusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `itlabexerciseusers` (
  `username` varchar(20) DEFAULT NULL,
  `phone` bigint DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `user_type` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `itlabexerciseusers`
--

LOCK TABLES `itlabexerciseusers` WRITE;
/*!40000 ALTER TABLE `itlabexerciseusers` DISABLE KEYS */;
INSERT INTO `itlabexerciseusers` VALUES ('root',6260070309,'$2y$10$QBr1Q0thQYeqbKuwGGPQ2OSvTmygt6GxrUAybNbiRNEMkoAbAvNiW','admin'),('pradumn',6260070309,'$2y$10$sNWENeGTPfewMv1LnFOaSuVg0cZ3IJdlRTYnwdYjAC7NJfSe6lRMC','admin'),('jatin ',6260070309,'$2y$10$eHcMcjJOsOzZEWtoFfXn2egOtuTFXa/85K9SA2B1MjCgDWFw7njjm','admin'),('spiker',62600703092,'$2y$10$0VxuWkMgiBY27fwK0YCceOjAtcpa8xYKtkZZ7fLj0qzo/XXCov4TC',NULL),('pn',62600703092,'$2y$10$WxJ.abv13Y6M/E7D02iXZeWpjqQcjy/0eOAMr5mV.wRCHJXBaRvrC',NULL),('root1',62600703092,'$2y$10$eVCMfivD0c8sSuA/FVJxGOr/9cW4cfuCsnr/FhvHJ.HhDSA/c2mFi',NULL),('root2',62600703092,'$2y$10$3cMLFNZwjcQm4wlmeCE0IO2HQhRjn21KG/eAPRuhnZhAeeqARWBH2',NULL),('root3',62600703092,'$2y$10$dsT2oSg6EpW/dSqezOXKV.UFc4enTShqI0mCMR3unk/hqV977dNla',NULL),('p',62600703092,'$2y$10$h1apY1PORA.vFgQdDKP/Qeje2B.VcZMZbdTsybBqFFnYRPEmuiwvq',NULL),('root5',6260070309,'$2y$10$d1g4mF3E1JCM1hUXEij.0ualYfjqjiQeeeXpnD0JJxWR0hB99pmPe','admin'),('raju',626007030925,'$2y$10$1IZRWCQRYTkfyv3jTbo1rOxT6Bbu6YS4Jyggd4j.hwKJEm7tx25eK',NULL),('t',6260070309,'$2y$10$d.ccBifpNkKZjT1bgtmZ9OJKpkaoMlGo2CD9sfrKVxeUqyG/tKpY6','admin'),('q',6260070309,'$2y$10$SLuHVhRtgKauNwX4Ho9bEuB4z4dc9UXKqBG/zx.XxSa0xRebeTExi','admin'),('yadav',8602052258,'$2y$10$QSDQk0CfR/290d8u4tfv4OMLYWyO3aY6EPVQxQo4kpiJMglYp7xB6','user'),('root',1234567895,'$2y$10$7C2BMntenBzoiS7BuTIA/uoocgIHeMB0Jn6H4WAww3xjGd5AeITKy','admin');
/*!40000 ALTER TABLE `itlabexerciseusers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-24 16:37:27
