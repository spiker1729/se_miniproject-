
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
   <script src="https://code.jquery.com/jquery-3.6.1.js" integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI=" crossorigin="anonymous"></script>
	<?php
if(isset($_POST['logoutButtonName'])) {
  session_destroy();

  header('location:login1.php');
}

?>
<style>
     body{

background-image: url("https://images.pexels.com/photos/1242348/pexels-photo-1242348.jpeg?auto=compress&cs=tinysrgb&w=600");           background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            background-attachment: fixed;


        }
form {
  width: 80%;
  margin: 0 auto;
}






  </style>
   <title>ADMIN</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#" style="margin-left: 50px;" >ADMIN DASHBOARD</a>

  <div >
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="add_event.php"  style="color:red; border:1px solid black ;" class="btn btn-primary">ADD PURCHASED ITEM <span class="sr-only">        </span></a>
        <a class="nav-link" href="user_event.php"  style="color:red; border:1px solid black ;" class="btn btn-primary">UPDATE stock of items  <span class="sr-only">        </span></a>
      </li>
      
      <li class="nav-item">
 
    </ul>
 






  </div>
</nav>
<p>
<?php

session_start();
echo "<br>";

echo" <p align='center'> <font color=blue  size='6pt'> HELLO : ".$_SESSION['username'];

?>
<form action="" method="post">

<br>
<button type="submit" name="logoutButtonName" class="btn btn-primary" style="right">Logout</button>
</from>

</p>
<hr>
<center><P>Available ITEMS</P></center>
<hr>


<table class="table">
        <thead>
            <tr>
                <th>ITEM_id</th>
                <th>ITEM_name</th>
                <th>TOTAL_quantity KG/Pcs</th>
                <th>quantity_available</th>
				<th>ITEM purchased ON</th>
              
            </tr>
        </thead>

        <tbody>
            <?php   
            $severname="localhost";
            $username="root";
            $password="password";
            $database="itlab";

            //create connection
            $connection =new mysqli($severname,$username,$password,$database);
            if($connection->connect_error){
                die("connection failed :".$connection->connect_error);
            }

            $sql="select * from item_details where quantity_available>'0'";
           // $sql1="select reg.no from info where reg.no='str'";
            $result =$connection->query($sql);
          //  $result1 =$connection->query($sql1);
            if(!$result){
                die("invalid query :".$connection->error);
            }
          

            while($row=$result->fetch_assoc()){
               
                echo"  <tr>
            <td>". $row["item_id"]."</td>
            <td>". $row["item_name"]."</td>
            <td>". $row["total_quantity"]."</td>
            <td>". $row["quantity_available"]."</td>
			<td>". $row["item_purchased_date"]."</td>
            
            </tr>";
            }

            
            ?>
        </tbody>
    </table>
</body>
</html>