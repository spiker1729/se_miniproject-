<?php
    include("connection.php");
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
<link rel="stylesheet" href="Design.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">


</head>
<body>
    
    <div class="header">
        <table>
            <tr>
                <td>
                    <!--<h1 style="text-align:center; color:#0F0"><b>Welcome Form</b></h1>-->
                </td>
                <td>
                     <h1 style="color:#FFF"><?php echo "User Name:  "?>
                            <b style="color:#C09"><?php echo $_SESSION['username']; ?></b>
                     </h1>
                                            
                </td>
                <td>
                    <a href="logout.php"><button type="submit" name="signup" style="color:white;background-color:black;">Log Out</button></a>
                </td>
            </tr>
        </table>      
    </div>
    <div class="welcome-container">
        <div> 
            <h1 style="color:#FFF"><?php echo "Welcome ".$_SESSION['username']; ?></h1>
        </div>         
        </div>
    </div>   
</body>
</html>
